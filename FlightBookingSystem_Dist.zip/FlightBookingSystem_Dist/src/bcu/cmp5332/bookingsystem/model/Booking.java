package bcu.cmp5332.bookingsystem.model;

import java.time.LocalDate;

public class Booking {

    private int id; // The unique identifier for the booking
    private Customer customer; // The customer who made the booking
    private Flight flight; // The flight booked by the customer
    private double price; // The price of the booking
    private LocalDate bookingDate; // The date when the booking was made
    private boolean cancelled; // Flag indicating whether the booking is cancelled
    private double cancellationFee; // The fee charged upon cancellation of the booking
    private double rebookFee; // The fee charged upon rebooking the flight

    /**
     * Constructs a new Booking object with the specified parameters.
     *
     * @param id          the unique identifier for the booking
     * @param customer    the customer who made the booking
     * @param flight      the flight booked by the customer
     * @param bookingDate the date when the booking was made
     * @param price       the price of the booking
     */
    public Booking(int id, Customer customer, Flight flight, LocalDate bookingDate, double price) {
        this.id = id;
        this.customer = customer;
        this.flight = flight;
        this.bookingDate = bookingDate;
        this.price = price;
        this.cancelled = false;
    }

    /**
     * Gets the unique identifier for the booking.
     *
     * @return the booking id
     */
    public int getId() {
        return id;
    }

    /**
     * Gets the customer who made the booking.
     *
     * @return the customer
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Sets the customer who made the booking.
     *
     * @param customer the customer to set
     */
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    /**
     * Gets the flight booked by the customer.
     *
     * @return the flight
     */
    public Flight getFlight() {
        return flight;
    }

    /**
     * Sets the flight booked by the customer.
     *
     * @param flight the flight to set
     */
    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    /**
     * Gets the date when the booking was made.
     *
     * @return the booking date
     */
    public LocalDate getBookingDate() {
        return bookingDate;
    }

    /**
     * Sets the date when the booking was made.
     *
     * @param bookingDate the booking date to set
     */
    public void setBookingDate(LocalDate bookingDate) {
        this.bookingDate = bookingDate;
    }

    /**
     * Gets the price of the booking.
     *
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Checks if the booking is cancelled.
     *
     * @return true if the booking is cancelled, false otherwise
     */
    public boolean isCancelled() {
        return cancelled;
    }

    /**
     * Cancels the booking and sets the cancellation fee.
     */
    public void cancelBooking() {
        if (!cancelled) { // Check if the booking is not already cancelled
            this.cancelled = true;
            flight.removePassenger(customer);

            // Set cancellation fee only if the booking is cancelled
            this.cancellationFee = price * 0.1;
        }
    }

    /**
     * Gets a string representation of the booking details.
     *
     * @return the booking details
     */
    public String getDetails() {
        StringBuilder details = new StringBuilder();
        details.append("Booking ID: ").append(id).append("\n");
        details.append("Customer: ").append(customer.getName()).append("\n");
        details.append("Flight: ").append(flight.getFlightNumber()).append("\n");
        details.append("Booking Date: ").append(bookingDate.toString()).append("\n");
        details.append("Price: ").append(price).append("\n");
        details.append("Status: ").append(cancelled ? "Cancelled" : "Active").append("\n");
        return details.toString();
    }

    /**
     * Gets the cancellation fee for the booking.
     *
     * @return the cancellation fee
     */
    public double getCancellationFee() {
        return cancellationFee;
    }

    /**
     * Sets the cancellation fee for the booking.
     *
     * @param cancellationFee the cancellation fee to set
     */
    public void setCancellationFee(double cancellationFee) {
        this.cancellationFee = cancellationFee;
    }

    /**
     * Gets the rebook fee for the booking.
     *
     * @return the rebook fee
     */
    public double getRebookFee() {
        return rebookFee;
    }

    /**
     * Sets the rebook fee for the booking.
     *
     * @param rebookFee the rebook fee to set
     */
    public void setRebookFee(double rebookFee) {
        this.rebookFee = rebookFee;
    }
}
