package bcu.cmp5332.bookingsystem.model;

import java.util.ArrayList;
import java.util.List;


public class Customer {

    private int id; // The unique identifier for the customer
    private String name; // The name of the customer
    private String phone; // The phone number of the customer
    private String email; // The email address of the customer
    private final List<Booking> bookings = new ArrayList<>(); // List of bookings made by the customer
    private boolean deleted; // Flag indicating whether the customer is deleted

    
    public Customer(int id, String name, String phone, String email) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.deleted = false;
    }

   
    public int getId() {
        return id;
    }

    
    public void setId(int id) {
        this.id = id;
    }

    
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the customer.
     *
     * @param name The name of the customer.
     */
    public void setName(String name) {
        this.name = name;
    }


    public String getPhone() {
        return phone;
    }

    
    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    
    public void setEmail(String email) {
        this.email = email;
    }

    
    public List<Booking> getBookings() {
        return bookings;
    }

    
    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    
    public String getDetailsShort() {
        return "Customer #" + id + " - " + name + " - " + phone + " - " + email;
    }

    
    public Booking getBookingByFlightId(int flightId) {
        for (Booking booking : bookings) {
            if (booking.getFlight().getId() == flightId) {
                return booking;
            }
        }
        return null;
    }

   
    public int getNumberOfBookings() {
        return bookings.size();
    }

    
    public void removeBooking(Booking booking) {
        bookings.remove(booking);
    }

    
    public boolean isDeleted() {
        return deleted;
    }

    
    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    
    public boolean isCancelled() {
        for (Booking booking : bookings) {
            if (booking.isCancelled()) {
                return true;
            }
        }
        return false;
    }

    
    public List<Booking> getActiveBookings() {
        List<Booking> activeBookings = new ArrayList<>();
        for (Booking booking : bookings) {
            if (!booking.isCancelled()) {
                activeBookings.add(booking);
            }
        }
        return activeBookings;
    }

    
    public void updateNumberOfBookings() {
        // Get the list of active bookings (not cancelled)
        List<Booking> activeBookings = getActiveBookings();

        // Update the number of bookings for the customer
        bookings.clear();
        bookings.addAll(activeBookings);
    }
}
