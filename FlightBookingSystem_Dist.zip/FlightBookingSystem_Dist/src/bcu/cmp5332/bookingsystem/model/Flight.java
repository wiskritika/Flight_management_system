package bcu.cmp5332.bookingsystem.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

public class Flight {

    private int id; // The unique identifier for the flight
    private String flightNumber; // The flight number
    private String origin; // The origin of the flight
    private String destination; // The destination of the flight
    private LocalDate departureDate; // The departure date of the flight
    private int numberOfSeats; // The total number of seats available on the flight
    private double price; // The price of the flight
    private final Set<Customer> passengers; // Set of passengers booked on the flight
    private List<Booking> bookings = new ArrayList<>(); // List of bookings associated with the flight
    private boolean deleted; // Flag indicating whether the flight is deleted

    /**
     * Constructs a new Flight object with the specified parameters.
     *
     * @param id            the unique identifier for the flight
     * @param flightNumber  the flight number
     * @param origin        the origin of the flight
     * @param destination   the destination of the flight
     * @param departureDate the departure date of the flight
     * @param numberOfSeats the total number of seats available on the flight
     * @param price         the price of the flight
     * @param deleted       flag indicating whether the flight is deleted
     */
    public Flight(int id, String flightNumber, String origin, String destination, LocalDate departureDate, int numberOfSeats, double price, boolean deleted) {
        this.id = id;
        this.flightNumber = flightNumber;
        this.origin = origin;
        this.destination = destination;
        this.departureDate = departureDate;
        this.numberOfSeats = numberOfSeats;
        this.price = price;
        this.passengers = new HashSet<>();
        this.deleted = deleted;
    }

    /**
     * Gets the unique identifier for the flight.
     *
     * @return the flight id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the unique identifier for the flight.
     *
     * @param id the flight id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the flight number.
     *
     * @return the flight number
     */
    public String getFlightNumber() {
        return flightNumber;
    }

    /**
     * Sets the flight number.
     *
     * @param flightNumber the flight number to set
     */
    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    /**
     * Gets the origin of the flight.
     *
     * @return the origin
     */
    public String getOrigin() {
        return origin;
    }

    /**
     * Sets the origin of the flight.
     *
     * @param origin the origin to set
     */
    public void setOrigin(String origin) {
        this.origin = origin;
    }

    /**
     * Gets the destination of the flight.
     *
     * @return the destination
     */
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the destination of the flight.
     *
     * @param destination the destination to set
     */
    public void setDestination(String destination) {
        this.destination = destination;
    }

    /**
     * Gets the departure date of the flight.
     *
     * @return the departure date
     */
    public LocalDate getDepartureDate() {
        return departureDate;
    }

    /**
     * Sets the departure date of the flight.
     *
     * @param departureDate the departure date to set
     */
    public void setDepartureDate(LocalDate departureDate) {
        this.departureDate = departureDate;
    }

    /**
     * Gets the total number of seats available on the flight.
     *
     * @return the number of seats
     */
    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    /**
     * Sets the total number of seats available on the flight.
     *
     * @param numberOfSeats the number of seats to set
     */
    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    /**
     * Gets the price of the flight.
     *
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the price of the flight.
     *
     * @param price the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Gets the list of passengers booked on the flight.
     *
     * @return the list of passengers
     */
    public List<Customer> getPassengers() {
        return new ArrayList<>(passengers);
    }

    /**
     * Gets a short string representation of the flight details.
     *
     * @return the short flight details
     */
    public String getDetailsShort() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY");
        return "Flight #" + id + " - " + flightNumber + " - " + origin + " to " + destination + " on " + departureDate.format(dtf) + " - Price: $" + price + " - Seats: " + numberOfSeats;
    }

    /**
     * Gets a long string representation of the flight details.
     *
     * @return the long flight details
     */
    public String getDetailsLong() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY");
        StringBuilder sb = new StringBuilder();
        sb.append("Flight #").append(id).append("\n");
        sb.append("Flight Number: ").append(flightNumber).append("\n");
        sb.append("Origin: ").append(origin).append("\n");
        sb.append("Destination: ").append(destination).append("\n");
        sb.append("Departure Date: ").append(departureDate.format(dtf)).append("\n");
        sb.append("Number of Seats: ").append(numberOfSeats).append("\n");
        sb.append("Price: Rs").append(price).append("\n");
        sb.append("Passengers: ").append("\n");
        for (Customer passenger : passengers) {
            sb.append(passenger.getName()).append("\n");
        }
        return sb.toString();
    }

    /**
     * Adds a passenger to the flight.
     *
     * @param customer the customer to add as a passenger
     */
    public void addPassenger(Customer customer) {
        if (passengers.size() >= numberOfSeats || departureDate.isBefore(LocalDate.now())) {
            return;
        }
        passengers.add(customer);
    }

    /**
     * Removes a passenger from the flight.
     *
     * @param customer the customer to remove
     */
    public void removePassenger(Customer customer) {
        passengers.removeIf(passenger -> passenger.equals(customer) && !passenger.isCancelled());
    }

    /**
     * Checks if the flight is deleted.
     *
     * @return true if the flight is deleted, false otherwise
     */
    public boolean isDeleted() {
        return deleted;
    }

    /**
     * Sets the flight as deleted.
     *
     * @param deleted the deleted flag to set
     */
    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    /**
     * Gets a booking by its ID.
     *
     * @param bookingId the ID of the booking
     * @return the booking with the specified ID, or null if not found
     */
    public Booking getBookingById(int bookingId) {
        for (Booking booking : bookings) {
            if (booking.getId() == bookingId) {
                return booking;
            }
        }
        return null;
    }

    /**
     * Removes a booking from the flight.
     *
     * @param booking the booking to remove
     */
    public void removeBooking(Booking booking) {
        bookings.remove(booking);
    }

    /**
     * Adds a booking to the flight.
     *
     * @param booking the booking to add
     */
    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    /**
     * Gets the non-cancelled bookings associated with the flight.
     *
     * @return an array of non-cancelled bookings
     */
    public Booking[] getBookings() {
        List<Booking> nonDeletedBookings = new ArrayList<>();
        for (Booking booking : bookings) {
            if (!booking.isCancelled()) {
                nonDeletedBookings.add(booking);
            }
        }
        return nonDeletedBookings.toArray(new Booking[0]);
    }

    /**
     * Checks if the flight has not departed yet.
     *
     * @param systemDate the current date
     * @return true if the flight has not departed, false otherwise
     */
    public boolean hasNotDeparted(LocalDate systemDate) {
        return departureDate.isAfter(systemDate);
    }

    /**
     * Calculates the price of the flight based on the current date and other factors.
     *
     * @param currentDate the current date
     * @return the calculated price
     * @throws FlightBookingSystemException if there are no seats available for booking
     */
    public int calculatePrice(LocalDate currentDate) throws FlightBookingSystemException {
        int bookedSeats = 0;
        for (Customer passenger : passengers) {
            if (!passenger.isCancelled()) {
                bookedSeats++;
            }
        }
        if (bookedSeats >= numberOfSeats) {
            return (int) price; // Return the original price
        }

        int daysLeft = (int) ChronoUnit.DAYS.between(currentDate, departureDate);
        int priceFactor;

        if (daysLeft >= 6) {
            priceFactor = 1; // Price factor for flights departing in more than 6 days
        } else if (daysLeft >= 1) {
            priceFactor = 2; // Price factor for flights departing in 1 to 5 days
        } else {
            priceFactor = 3; // Price factor for flights departing within 24 hours
        }

        double finalPrice = price * priceFactor;

        int seatsLeft = numberOfSeats - bookedSeats;
        if (seatsLeft <= 0) {
            throw new FlightBookingSystemException("No seats available for booking.");
        }

        double seatsPriceIncrease = 0.0;
        if (seatsLeft <= 4) {
            seatsPriceIncrease = 50.0 * (5 - seatsLeft); // Increase price by $50 for each seat less than 5
        }

        finalPrice += seatsPriceIncrease;

        return (int) finalPrice;
    }

    /**
     * Checks if the flight is fully booked.
     *
     * @return true if the flight is fully booked, false otherwise
     */
    public boolean isFullyBooked() {
        int bookedSeats = 0;
        for (Customer passenger : passengers) {
            if (!passenger.isCancelled()) {
                bookedSeats++;
            }
        }
        return bookedSeats >= numberOfSeats;
    }
}
