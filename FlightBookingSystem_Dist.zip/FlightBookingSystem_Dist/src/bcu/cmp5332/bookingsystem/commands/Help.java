package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The Help class implements the Command interface and represents a command 
 * to display the help message listing all available commands and their descriptions.
 * 
 * This command prints the help message to the standard output.
 * 
 * @author Kevin, Kritika
 */
public class Help implements Command {

    /**
     * Executes the command to display the help message.
     *
     * @param flightBookingSystem The flight booking system.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) {
        System.out.println(Command.HELP_MESSAGE);
    }
}
