package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

/**
 * The Command interface represents a command that can be executed in the flight booking system.
 * 
 * Each command should implement the execute method to perform its specific actions.
 * The HELP_MESSAGE provides a list of available commands and their descriptions.
 * 
 * @author Kevin, Kritika
 */
public interface Command {

    /**
     * A help message that lists all the available commands and their descriptions.
     */
    public static final String HELP_MESSAGE = "Commands:\n"
        + "\tlistflights                               print all flights\n"
        + "\tlistcustomers                             print all customers\n"
        + "\taddflight                                 add a new flight\n"
        + "\tdeleteflight                              delete a flight\n"
        + "\taddcustomer                               add a new customer\n"
        + "\tshowflight [flight id]                    show flight details\n"
        + "\tshowcustomer [customer id]                show customer details\n"
        + "\taddbooking [customer id] [flight id]      add a new booking\n"
        + "\tcancelbooking [customer id] [flight id]   cancel a booking\n"
        + "\teditbooking [booking id] [flight id]      update a booking\n"
        + "\tloadgui                                   loads the GUI version of the app\n"
        + "\thelp                                      prints this help message\n"
        + "\texit                                      exits the program";

    /**
     * Executes the command with the provided flight booking system.
     *
     * @param flightBookingSystem The flight booking system.
     * @throws FlightBookingSystemException If an error occurs while executing the command.
     */
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException;
}
