package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * The ListFlights class implements the Command interface and represents a command 
 * to list all upcoming flights in the flight booking system.
 * 
 * This command reads flight data from a file, filters out past flights, and prints each 
 * flight's short details.
 * 
 * @author Kevin, Kritika
 */
public class ListFlights implements Command {

    /**
     * Executes the command to list all upcoming flights in the flight booking system.
     *
     * @param flightBookingSystem The flight booking system.
     * @throws FlightBookingSystemException If an error occurs while executing the command.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        List<Flight> flights = readFlightsFromFile("resources/data/flights.txt");
        LocalDate today = LocalDate.now();
        flights = filterFlights(flights, today);
        for (Flight flight : flights) {
            System.out.println(flight.getDetailsShort());
        }
        System.out.println(flights.size() + " flight(s)");
    }

    /**
     * Reads flight data from the specified file and returns a list of flights.
     *
     * @param filename The name of the file to read from.
     * @return A list of flights.
     * @throws FlightBookingSystemException If an error occurs while reading the file.
     */
    private List<Flight> readFlightsFromFile(String filename) throws FlightBookingSystemException {
        List<Flight> flights = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String flightNumber = parts[1];
                String origin = parts[2];
                String destination = parts[3];
                LocalDate departureDate = LocalDate.parse(parts[4]);
                int numberOfSeats = Integer.parseInt(parts[5]);
                double price = Double.parseDouble(parts[6]);
                boolean deleted = Boolean.parseBoolean(parts[7]);

                Flight flight = new Flight(id, flightNumber, origin, destination, departureDate, numberOfSeats, price, deleted);
                flights.add(flight);
            }
        } catch (IOException | NumberFormatException e) {
            throw new FlightBookingSystemException("Error reading flights from file: " + e.getMessage());
        }
        return flights;
    }

    /**
     * Filters out past flights and returns a list of upcoming flights.
     *
     * @param flights The list of flights to filter.
     * @param today The current date.
     * @return A list of upcoming flights.
     */
    private List<Flight> filterFlights(List<Flight> flights, LocalDate today) {
        return flights.stream()
                .filter(flight -> flight.getDepartureDate().isAfter(today))
                .collect(Collectors.toList());
    }
}
