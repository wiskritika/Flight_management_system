package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import bcu.cmp5332.bookingsystem.gui.LoginWindow;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

/**
 * The LoadGUI class implements the Command interface and represents a command 
 * to load the GUI version of the flight booking system.
 * 
 * This command initializes and displays the login window for the GUI.
 * 
 * @author Kevin, Kritika
 */
public class LoadGUI implements Command {

    private final FlightBookingSystem flightBookingSystem;

    /**
     * Constructs a LoadGUI command with the specified flight booking system.
     * 
     * @param flightBookingSystem The flight booking system.
     */
    public LoadGUI(FlightBookingSystem flightBookingSystem) {
        this.flightBookingSystem = flightBookingSystem;
    }

    /**
     * Executes the command to load the GUI version of the flight booking system.
     *
     * @param flightBookingSystem The flight booking system.
     * @throws FlightBookingSystemException If an error occurs while executing the command.
     */
    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        new LoginWindow(flightBookingSystem).setVisible(true);
    }
}
