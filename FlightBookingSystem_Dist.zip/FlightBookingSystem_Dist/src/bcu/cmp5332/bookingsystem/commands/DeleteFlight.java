package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.data.FlightDataManager;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.io.IOException;

/**
 * The DeleteFlight class implements the Command interface and represents a command 
 * to delete an existing flight from the flight booking system.
 * 
 * This command deletes a flight identified by its ID and updates the system data accordingly.
 * 
 * Upon successful execution, the flight is deleted and the updated data is stored.
 * 
 * @author Kevin, Kritika
 */
public class DeleteFlight implements Command {

    private final int flightId; // ID of the flight to be deleted

    /**
     * Constructs a DeleteFlight command with the specified flight ID.
     * 
     * @param flightId the ID of the flight to be deleted
     */
    public DeleteFlight(int flightId) {
        this.flightId = flightId;
    }

    /**
     * Executes the command to delete a flight from the flight booking system.
     *
     * @param fbs The flight booking system.
     * @throws FlightBookingSystemException If an error occurs while executing the command.
     */
    @Override
    public void execute(FlightBookingSystem fbs) throws FlightBookingSystemException {
        // Delete the flight
        fbs.deleteFlight(flightId);

        // Store updated data
        FlightDataManager dataManager = new FlightDataManager();
        try {
            dataManager.storeData(fbs);
        } catch (IOException e) {
            throw new FlightBookingSystemException("Error storing flight data: " + e.getMessage());
        }

        System.out.println("Flight successfully deleted for flight ID: " + flightId);
    }
}
