package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import bcu.cmp5332.bookingsystem.data.FlightDataManager;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * The DisplayFlightsWindow class is a JPanel that displays a table of flight details.
 * It allows users to view flight information and mark flights as deleted.
 */
public class DisplayFlightsWindow extends JPanel {

    private static final long serialVersionUID = 1L;
    private FlightBookingSystem fbs;
    private Image backgroundImage;
    private MainWindow mainWindow;
    private FlightDataManager fdm;

    /**
     * Constructs a DisplayFlightsWindow with the specified FlightBookingSystem and MainWindow.
     *
     * @param fbs the flight booking system
     * @param mainWindow the main window
     */
    public DisplayFlightsWindow(FlightBookingSystem fbs, MainWindow mainWindow) {
        this.fbs = fbs;
        this.mainWindow = mainWindow;
        this.fdm = new FlightDataManager();
        try {
            backgroundImage = new ImageIcon("resources/images/background1.jpg").getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }
        initialize();
    }

    /**
     * Initializes the components and layout of the panel.
     */
    private void initialize() {
        setLayout(new BorderLayout());

        JLabel headingLabel = new JLabel("Flight Details", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 30));
        headingLabel.setOpaque(true);
        headingLabel.setBackground(new Color(255, 255, 255)); 
        headingLabel.setForeground(Color.BLACK);
        headingLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        String[] columns = {"Flight ID", "Flight No", "Origin", "Destination", "Departure Date", "Number of Seats", "Price", "Fully Booked", "Departed", "Status", "Delete Flight"};
        Object[][] data = getFlightsData();

        DefaultTableModel tableModel = new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 10; // Only the "Delete Flight" column is editable
            }
        };

        JTable table = new JTable(tableModel);
        table.getColumn("Delete Flight").setCellRenderer(new ButtonRenderer());
        table.getColumn("Delete Flight").setCellEditor(new ButtonEditor(new JCheckBox(), table, this));

        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(1000, 600));
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.setBackground(new Color(255, 255, 255, 150));

        // Add Flights button
        JButton addFlightButton = new JButton("Add Flights");
        addFlightButton.setFont(new Font("Arial", Font.BOLD, 20));
        addFlightButton.setForeground(Color.BLACK);
        addFlightButton.setBackground(new Color(128, 128, 128));  
        addFlightButton.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));  
        addFlightButton.setPreferredSize(new Dimension(200, 50)); 

        // Add hover effect to the button
        addFlightButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addFlightButton.setBackground(new Color(128, 128, 70));  
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                addFlightButton.setBackground(new Color(128, 128, 128));  
            }
        });

        addFlightButton.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new AddFlightWindow(mainWindow); 
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(addFlightButton);

        add(headingLabel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Retrieves the flight data to be displayed in the table.
     *
     * @return a 2D array containing flight data
     */
    private Object[][] getFlightsData() {
        List<Flight> flights = fbs.getFlights();
        Object[][] data = new Object[flights.size()][11];
        for (int i = 0; i < flights.size(); i++) {
            Flight flight = flights.get(i);
            boolean fullyBooked = flight.getNumberOfSeats() <= 0;
            boolean departed = flight.getDepartureDate().isBefore(LocalDate.now());
            String price = flight.isDeleted() ? "N/A" : String.valueOf(flight.getPrice());
            data[i] = new Object[]{
                flight.getId(),
                flight.getFlightNumber(),
                flight.getOrigin(),
                flight.getDestination(),
                flight.getDepartureDate(),
                flight.getNumberOfSeats(),
                price,
                fullyBooked ? "Yes" : "No",
                departed ? "Yes" : "No",
                flight.isDeleted() ? "Deleted" : "Active",
                "Delete Flight"
            };
        }
        return data;
    }

    /**
     * Styles the table with custom fonts, colors, and hover effects.
     *
     * @param table the JTable to style
     */
    private void styleTable(JTable table) {
        table.setFont(new Font("Arial", Font.BOLD, 16));
        table.setRowHeight(30);
        table.setBackground(Color.DARK_GRAY); // Dark grey for the table background
        table.setForeground(Color.WHITE); // White text color
        table.setGridColor(Color.WHITE);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);

        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setDefaultRenderer(new GradientTableHeaderRenderer());
        tableHeader.setPreferredSize(new Dimension(tableHeader.getWidth(), 35));
        tableHeader.setBackground(Color.DARK_GRAY);
        tableHeader.setForeground(Color.WHITE);
        tableHeader.setFont(new Font("Arial", Font.BOLD, 18));
        tableHeader.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        table.setSelectionBackground(new Color(0, 102, 204)); // Darker blue for selected row
        table.setSelectionForeground(Color.WHITE);

        // Hover effect for rows
        table.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                int row = table.rowAtPoint(evt.getPoint());
                if (row > -1) {
                    table.setRowSelectionInterval(row, row);
                } else {
                    table.clearSelection();
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    /**
     * Custom button renderer for the "Delete Flight" column.
     */
    private class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    /**
     * Custom button editor for the "Delete Flight" column.
     */
    private class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isPushed;
        private JTable table;
        private DisplayFlightsWindow parent;

        /**
         * Constructs a ButtonEditor with the specified parameters.
         *
         * @param checkBox the JCheckBox
         * @param table the JTable
         * @param parent the DisplayFlightsWindow
         */
        public ButtonEditor(JCheckBox checkBox, JTable table, DisplayFlightsWindow parent) {
            super(checkBox);
            this.table = table;
            this.parent = parent;
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isPushed = true;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                int selectedRow = table.getSelectedRow();
                int flightId = (int) table.getValueAt(selectedRow, 0);
                try {
                    fdm.deleteFlight(flightId, fbs); // Mark flight as deleted
                    table.setValueAt("Deleted", selectedRow, 9); // Update the status in the table
                    table.setValueAt("N/A", selectedRow, 6); // Set price to "N/A"
                    JOptionPane.showMessageDialog(parent, "Flight marked as deleted successfully.");
                } catch (IOException | FlightBookingSystemException ex) {
                    JOptionPane.showMessageDialog(parent, "Failed to mark flight as deleted: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            isPushed = false;
            return label;
        }

        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }

    /**
     * Custom header renderer with a gradient background for the table header.
     */
    private class GradientTableHeaderRenderer extends DefaultTableCellRenderer {
        private Border darkBorder = BorderFactory.createLineBorder(Color.DARK_GRAY, 1);

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel cellLabel = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            cellLabel.setHorizontalAlignment(JLabel.CENTER);
            cellLabel.setForeground(Color.BLACK); // Black text for better contrast
            cellLabel.setBorder(darkBorder); // Dark border for cells
            return cellLabel;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            Color startColor = new Color(0, 51, 102);
            Color endColor = new Color(51, 153, 255);
            int width = getWidth();
            int height = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, startColor, 0, height, endColor);
            g2.setPaint(gp);
            g2.fillRect(0, 0, width, height);
            super.paintComponent(g);
        }
    }
}
