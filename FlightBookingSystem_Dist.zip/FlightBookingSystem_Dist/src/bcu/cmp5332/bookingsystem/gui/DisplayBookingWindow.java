package bcu.cmp5332.bookingsystem.gui;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * JPanel for displaying bookings in a table format.
 * 
 * @author Kritika, Kevin
 * 
 */
public class DisplayBookingWindow extends JPanel {

    private static final long serialVersionUID = 1L;
    private Image backgroundImage;

    /**
     * Constructs a new DisplayBookingsWindow.
     */
    public DisplayBookingWindow() {
        try {
            backgroundImage = new ImageIcon("resources/images/background1.jpg").getImage();
        } catch (Exception e) {
            e.printStackTrace();
        }
        initialize();
    }

    /**
     * Initializes the DisplayBookingsWindow.
     */
    private void initialize() {
        setLayout(new BorderLayout());

        JLabel headingLabel = new JLabel("Booking Details", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 30));
        headingLabel.setOpaque(true);
        headingLabel.setBackground(Color.WHITE);
        headingLabel.setForeground(Color.BLACK);
        headingLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        String[] columns = {"Booking ID", "Customer ID", "Flight ID", "Booking Date", "Price", "Status"};
        Object[][] data = readBookingsFromFile("resources/data/bookings.txt");

        JTable table = new JTable(data, columns);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(1000, 600));
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.setBackground(new Color(255, 255, 255, 150)); // White with transparency

        add(headingLabel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }

    /**
     * Reads bookings from a file and converts them into a 2D array.
     *
     * @param filename The name of the file containing bookings.
     * @return A 2D array representing bookings data.
     */
    private Object[][] readBookingsFromFile(String filename) {
        List<Object[]> bookingsData = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                int bookingId = Integer.parseInt(parts[0]);
                int customerId = Integer.parseInt(parts[1]);
                int flightId = Integer.parseInt(parts[2]);
                String bookingDate = parts[3];
                double price = Double.parseDouble(parts[4]);
                String status = parts.length > 5 && parts[5].equals("cancelled") ? "Cancelled" : "Active";

                bookingsData.add(new Object[]{bookingId, customerId, flightId, bookingDate, price, status});
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error reading bookings from file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return bookingsData.toArray(new Object[0][]);
    }

    /**
     * Applies custom styling to the JTable.
     *
     * @param table The JTable to style.
     */
    private void styleTable(JTable table) {
        table.setFont(new Font("Arial", Font.PLAIN, 16));
        table.setRowHeight(30);
        table.setBackground(new Color(245, 245, 245)); // Very light gray for the table background
        table.setForeground(Color.BLACK);
        table.setGridColor(Color.LIGHT_GRAY);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);

        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setDefaultRenderer(new GradientTableHeaderRenderer());
        tableHeader.setPreferredSize(new Dimension(tableHeader.getWidth(), 35));
        tableHeader.setBackground(new Color(0, 51, 102));
        tableHeader.setForeground(Color.WHITE);
        tableHeader.setFont(new Font("Arial", Font.BOLD, 18));
        tableHeader.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        table.setSelectionBackground(new Color(0, 102, 204)); // Darker blue for selected row
        table.setSelectionForeground(Color.WHITE);

        // Hover effect for rows
        table.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                int row = table.rowAtPoint(evt.getPoint());
                if (row > -1) {
                    table.setRowSelectionInterval(row, row);
                } else {
                    table.clearSelection();
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

    private class GradientTableHeaderRenderer extends DefaultTableCellRenderer {
        private Border darkBorder = BorderFactory.createLineBorder(Color.DARK_GRAY, 1);

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel cellLabel = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            cellLabel.setHorizontalAlignment(JLabel.CENTER);
            cellLabel.setForeground(Color.BLACK); // Black text for better contrast
            cellLabel.setBorder(darkBorder); // Dark border for cells
            return cellLabel;
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            Color startColor = new Color(0, 51, 102);
            Color endColor = new Color(51, 153, 255);
            int width = getWidth();
            int height = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, startColor, 0, height, endColor);
            g2.setPaint(gp);
            g2.fillRect(0, 0, width, height);
            super.paintComponent(g);
        }
    }
}
