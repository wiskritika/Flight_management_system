package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import javax.swing.*;
import java.awt.*;

/**
 * The DeleteCustomerWindow class represents a graphical user interface window for deleting a customer
 * in the Flight Booking System application.
 *
 * This class provides a user interface where the user can enter a customer ID. When the user
 * deletes the customer, the corresponding customer is removed from the system.
 *
 * The DeleteCustomerWindow class extends the JFrame class, which provides the basic structure
 * of the GUI window and allows it to be displayed as a standalone window for customer deletion.
 * 
 * @authored Kevin, Kritika
 */
public class DeleteCustomerWindow extends JFrame {

    private FlightBookingSystem fbs;

    /**
     * Constructs a new DeleteCustomerWindow.
     *
     * @param fbs the FlightBookingSystem instance
     */
    public DeleteCustomerWindow(FlightBookingSystem fbs) {
        this.fbs = fbs;
        initialize();
    }

    /**
     * Initializes the DeleteCustomerWindow by setting up the UI components.
     */
    private void initialize() {
        setTitle("Delete Customer");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(0, 51, 102)); // Dark blue background

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel customerIdLabel = new JLabel("Enter Customer ID:");
        customerIdLabel.setFont(new Font("Arial", Font.BOLD, 24));
        customerIdLabel.setForeground(Color.WHITE); // White text for label
        customerIdLabel.setPreferredSize(new Dimension(150, 25));
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(customerIdLabel, gbc);

        JTextField customerIdField = new JTextField();
        customerIdField.setBackground(Color.WHITE); // White background for input field
        customerIdField.setForeground(Color.BLACK); // Black text for input field
        customerIdField.setPreferredSize(new Dimension(150, 25));
        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(customerIdField, gbc);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14)); // Bold font
        deleteButton.setForeground(Color.BLACK); // Black text color
        deleteButton.setBackground(new Color(0, 0, 64)); // Darker blue color
        deleteButton.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2)); // Dark gray border
        deleteButton.setFocusPainted(false); // Remove focus border
        deleteButton.setPreferredSize(new Dimension(150, 40));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(deleteButton, gbc);

        deleteButton.addActionListener(e -> {
            String input = customerIdField.getText();
            if (input != null && !input.isEmpty()) {
                try {
                    int customerId = Integer.parseInt(input);
                    deleteCustomer(customerId);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Please enter a valid customer ID.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        add(panel, BorderLayout.CENTER);

        setVisible(true);
    }

    /**
     * Deletes the customer with the specified ID.
     *
     * @param customerId the ID of the customer to be deleted
     */
    private void deleteCustomer(int customerId) {
        try {
            fbs.deleteCustomer(customerId);
            JOptionPane.showMessageDialog(this, "Customer deleted successfully.");
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
