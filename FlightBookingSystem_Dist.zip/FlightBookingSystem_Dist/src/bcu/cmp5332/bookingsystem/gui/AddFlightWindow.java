package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.commands.AddFlight;
import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * It represents a window for adding a new flight to the flight booking system.
 * 
 * @author Kritika, Kevin
 */
public class AddFlightWindow extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;

    private MainWindow mw;
    private JTextField flightNoText = new JTextField();
    private JTextField originText = new JTextField();
    private JTextField destinationText = new JTextField();
    private JTextField depDateText = new JTextField();
    private JTextField seatsText = new JTextField();
    private JTextField priceText = new JTextField();

    private JButton addBtn = new JButton("Add");
    private JButton cancelBtn = new JButton("Cancel");

    private static final Color PRIMARY_COLOR = new Color(0, 51, 102); // Dark blue
    private static final Color BACKGROUND_COLOR = new Color(0, 51, 102); // Dark blue
    private static final Color FIELD_COLOR = Color.WHITE; // White for text fields
    private static final Color BUTTON_COLOR = Color.WHITE; // White for buttons
    private static final Color BUTTON_TEXT_COLOR = Color.BLACK; // Black text for buttons
    private static final Color LABEL_COLOR = Color.WHITE; // White text for labels

    /**
     * Constructs an AddFlightWindow object with the specified MainWindow.
     *
     * @param mw The MainWindow object.
     */
    public AddFlightWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Initializes the AddFlightWindow by setting up the UI components.
     */
    private void initialize() {
        setTitle("Add a New Flight");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(BACKGROUND_COLOR);

        JLabel headingLabel = new JLabel("Add Flight", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headingLabel.setForeground(LABEL_COLOR);
        headingLabel.setOpaque(true);
        headingLabel.setBackground(PRIMARY_COLOR);
        headingLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        contentPanel.add(headingLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components

        // Flight Number
        addFormField(formPanel, gbc, "Flight Number:", flightNoText);

        // Origin
        addFormField(formPanel, gbc, "Origin:", originText);

        // Destination
        addFormField(formPanel, gbc, "Destination:", destinationText);

        // Departure Date
        addFormField(formPanel, gbc, "Departure Date (YYYY-MM-DD):", depDateText);

        // Number of Seats
        addFormField(formPanel, gbc, "Number of Seats:", seatsText);

        // Price
        addFormField(formPanel, gbc, "Price:", priceText);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(BACKGROUND_COLOR);
        styleButton(addBtn);
        styleButton(cancelBtn);
        buttonPanel.add(addBtn);
        buttonPanel.add(cancelBtn);

        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        contentPanel.add(formPanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(contentPanel);
        setLocationRelativeTo(mw);
        setVisible(true);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, String label, JTextField textField) {
        JLabel fieldLabel = new JLabel(label);
        fieldLabel.setFont(new Font("Arial", Font.BOLD, 14));
        fieldLabel.setForeground(LABEL_COLOR); // White text for labels
        textField.setPreferredSize(new Dimension(250, 30));
        textField.setBackground(FIELD_COLOR); // White background for text fields
        textField.setForeground(Color.BLACK); // Black text in text fields
        textField.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        
        gbc.gridx = 0;
        panel.add(fieldLabel, gbc);
        gbc.gridx = 1;
        panel.add(textField, gbc);
        gbc.gridy++;
    }

    private void styleButton(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR); // White background for buttons
        button.setForeground(BUTTON_TEXT_COLOR); // Black text for buttons
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(120, 40));
        button.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    /**
     * Handles the action events for the Add and Cancel buttons.
     *
     * @param ae The ActionEvent object.
     */
    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            addFlight();
        } else if (ae.getSource() == cancelBtn) {
            setVisible(false); // Hide the window
        }
    }

    /**
     * Adds a new flight to the flight booking system based on the user input.
     */
    private void addFlight() {
        try {
            String flightNumber = flightNoText.getText().trim();
            String origin = originText.getText().trim();
            String destination = destinationText.getText().trim();
            LocalDate departureDate = LocalDate.parse(depDateText.getText().trim());
            int numberOfSeats = Integer.parseInt(seatsText.getText().trim());
            int price = Integer.parseInt(priceText.getText().trim());

            if (flightNumber.isEmpty() || origin.isEmpty() || destination.isEmpty()) {
                throw new FlightBookingSystemException("Invalid Flight Number, Origin, or Destination!");
            }

            if (numberOfSeats <= 0 || price <= 0) {
                throw new FlightBookingSystemException("Invalid number of seats or price! Please enter a valid number.");
            }

            if (departureDate.isBefore(LocalDate.now())) {
                throw new FlightBookingSystemException("Invalid Departure Date! Please enter a valid date.");
            }

            boolean deleted = false;
            Command addFlight = new AddFlight(flightNumber, origin, destination, departureDate, numberOfSeats, price, deleted);
            addFlight.execute(mw.getFlightBookingSystem());

            // Show success message in popup dialog
            JOptionPane.showMessageDialog(this, "Flight added successfully.");

            // Clear fields after successful addition
            clearFields();
        } catch (DateTimeParseException dtpe) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Please use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Invalid number format. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Clears the text fields in the AddFlightWindow.
     */
    private void clearFields() {
        flightNoText.setText("");
        originText.setText("");
        destinationText.setText("");
        depDateText.setText("");
        seatsText.setText("");
        priceText.setText("");
    }
}
