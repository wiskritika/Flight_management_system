package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;

import javax.swing.*;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import java.io.IOException;

/**
 * The LoadingWindow class represents a window that displays a loading screen
 * with a progress bar, an airplane image, and a background with images of Nepal and England.
 * It loads the FlightBookingSystem data and transitions to the main window once loading is complete.
 */
public class LoadingWindow extends JFrame {

    private JProgressBar progressBar;
    private JLabel airplaneLabel;
    private JLabel loadingLabel;
    private Timer timer;
    private int progress = 0;
    private FlightBookingSystem fbs;
    private Image nepalImage;
    private Image englandImage;

    private int nepalX, nepalY, englandX, englandY;

    /**
     * Constructs a LoadingWindow and initializes its components.
     */
    public LoadingWindow() {
        setTitle("Loading...");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLayout(new GridBagLayout());

        // Set professional background color
        setContentPane(new ColorPanel(new Color(34, 45, 50))); // Dark grayish-blue color
        GridBagConstraints gbc = new GridBagConstraints();

        // Load Nepal and England images
        nepalImage = new ImageIcon("resources/images/nepal.png").getImage();
        englandImage = new ImageIcon("resources/images/uk.png").getImage();

        gbc.insets = new Insets(20, 20, 20, 20);

        // Loading Label
        loadingLabel = new JLabel("Loading...");
        loadingLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        loadingLabel.setForeground(Color.WHITE);
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        add(loadingLabel, gbc);

        // Progress Bar
        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setPreferredSize(new Dimension(600, 40));
        progressBar.setForeground(new Color(70, 130, 180)); // Blue color
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        add(progressBar, gbc);

        // Airplane Image
        ImageIcon airplaneIcon = new ImageIcon("resources/images/loading.png");
        Image airplaneImage = airplaneIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        airplaneLabel = new JLabel(new ImageIcon(airplaneImage));
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        add(airplaneLabel, gbc);

        loadFlightBookingSystem();
        startLoading();
    }

    /**
     * Loads the flight booking system data.
     */
    private void loadFlightBookingSystem() {
        try {
            fbs = FlightBookingSystemData.load();
        } catch (IOException | FlightBookingSystemException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading flight booking system.", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    /**
     * Starts the loading process, updating the progress bar and moving the airplane image.
     */
    private void startLoading() {
        timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                progress++;
                progressBar.setValue(progress);
                moveAirplane();
                if (progress >= 100) {
                    timer.cancel();
                    dispose();
                    SwingUtilities.invokeLater(() -> new MainWindow(fbs).setVisible(true));
                }
            }
        };
        timer.scheduleAtFixedRate(task, 0, 50);
    }

    /**
     * Moves the airplane image along a path from Nepal to England based on the loading progress.
     */
    private void moveAirplane() {
        int totalWidth = getWidth();
        int totalHeight = getHeight();

        // Calculate the positions
        nepalX = 230;
        nepalY = totalHeight - 380;
        englandX = totalWidth - 400;
        englandY = totalHeight - 400;

        // Calculate current position based on progress
        int x = nepalX + (int) ((englandX - nepalX) * (progress / 100.0));
        int y = nepalY + (int) ((englandY - nepalY) * (progress / 100.0));

        airplaneLabel.setLocation(x, y);
    }

    /**
     * The main method to launch the LoadingWindow.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LoadingWindow().setVisible(true));
    }

    /**
     * The ColorPanel class represents a JPanel with a specific background color.
     * It also draws the Nepal and England images on the panel.
     */
    class ColorPanel extends JPanel {
        private Color backgroundColor;

        /**
         * Constructs a ColorPanel with the specified background color.
         *
         * @param backgroundColor the background color of the panel
         */
        public ColorPanel(Color backgroundColor) {
            this.backgroundColor = backgroundColor;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(backgroundColor);
            g.fillRect(0, 0, getWidth(), getHeight());

            // Draw Nepal and England maps
            int panelHeight = getHeight();
            nepalX = 230;
            nepalY = panelHeight - 380;
            englandX = getWidth() - 500;
            englandY = panelHeight - 400;

            int mapWidth = 300;
            int mapHeight = 300;

            g.drawImage(nepalImage, nepalX, nepalY, mapWidth, mapHeight, this);
            g.drawImage(englandImage, englandX, englandY, mapWidth, mapHeight, this);
        }
    }
}
