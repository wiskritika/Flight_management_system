package bcu.cmp5332.bookingsystem.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;
import bcu.cmp5332.bookingsystem.data.BookingDataManager;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;

/**
 * The LoginWindow class represents the login window for the flight booking system.
 */
public class LoginWindow extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private final FlightBookingSystem flightBookingSystem;

    /**
     * Constructs a LoginWindow with the given flight booking system.
     *
     * @param flightBookingSystem the flight booking system
     */
    public LoginWindow(FlightBookingSystem flightBookingSystem) {
        this.flightBookingSystem = flightBookingSystem;

        setTitle("Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        // Set gradient background
        setContentPane(new GradientPanel());
        GridBagConstraints gbc = new GridBagConstraints();

        // Add logo with circular white background
        CircularBackgroundPanel logoPanel = new CircularBackgroundPanel("resources/images/Logo.png");
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.NORTH;
        add(logoPanel, gbc);

        // Login form panel
        JPanel panel = new RoundedPanel(20, new Color(255, 255, 255, 200));
        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        panel.setPreferredSize(new Dimension(300, 150));

        GridBagConstraints formGbc = new GridBagConstraints();

        // Username label
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        usernameLabel.setForeground(Color.BLACK);
        formGbc.gridx = 0;
        formGbc.gridy = 0;
        formGbc.insets = new Insets(5, 5, 5, 5);
        panel.add(usernameLabel, formGbc);

        // Username field
        usernameField = new JTextField(15);
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formGbc.gridx = 1;
        formGbc.gridy = 0;
        formGbc.insets = new Insets(5, 5, 5, 5);
        panel.add(usernameField, formGbc);

        // Password label
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordLabel.setForeground(Color.BLACK);
        formGbc.gridx = 0;
        formGbc.gridy = 1;
        formGbc.insets = new Insets(5, 5, 5, 5);
        panel.add(passwordLabel, formGbc);

        // Password field
        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        formGbc.gridx = 1;
        formGbc.gridy = 1;
        formGbc.insets = new Insets(5, 5, 5, 5);
        panel.add(passwordField, formGbc);

        // Login button
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setBackground(new Color(70, 130, 180));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        loginButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginButton.setContentAreaFilled(false);
        loginButton.setOpaque(true);
        formGbc.gridx = 0;
        formGbc.gridy = 2;
        formGbc.gridwidth = 2;
        formGbc.insets = new Insets(10, 5, 5, 5);
        panel.add(loginButton, formGbc);

        // Add hover effect to button
        loginButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                loginButton.setBackground(new Color(100, 149, 237));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                loginButton.setBackground(new Color(70, 130, 180));
            }
        });

        // Add panel to the center
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        add(panel, gbc);

        // Action Listener for login button
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Updated validation logic
                if (username.equals("admin") && password.equals("admin123")) {
                    dispose();
                    new LoadingWindow().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password.");
                }
            }
        });
    }

    /**
     * The main method to launch the LoginWindow.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        try {
            FlightBookingSystem fbs = FlightBookingSystemData.load();
            new LoginWindow(fbs).setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

/**
 * The GradientPanel class represents a JPanel with a gradient background.
 */
class GradientPanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        int width = getWidth();
        int height = getHeight();
        Color color1 = new Color(240, 240, 240);
        Color color2 = new Color(200, 200, 200);
        GradientPaint gp = new GradientPaint(0, 0, color1, 0, height, color2);
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, width, height);
    }
}

/**
 * The CircularBackgroundPanel class represents a JPanel with a circular white background and a logo image.
 */
class CircularBackgroundPanel extends JPanel {
    private final Image logoImage;

    /**
     * Constructs a CircularBackgroundPanel with the given image path.
     *
     * @param imagePath the path to the logo image
     */
    public CircularBackgroundPanel(String imagePath) {
        ImageIcon logoIcon = new ImageIcon(imagePath);
        this.logoImage = logoIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        setPreferredSize(new Dimension(120, 120)); // Adjust as needed for padding
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw circular background
        int diameter = Math.min(getWidth(), getHeight());
        int x = (getWidth() - diameter) / 2;
        int y = (getHeight() - diameter) / 2;
        g2d.setColor(Color.WHITE);
        g2d.fillOval(x, y, diameter, diameter);

        // Draw the logo image centered in the panel
        int imgX = (getWidth() - logoImage.getWidth(this)) / 2;
        int imgY = (getHeight() - logoImage.getHeight(this)) / 2;
        g2d.drawImage(logoImage, imgX, imgY, this);
    }
}

/**
 * The RoundedPanel class represents a JPanel with rounded corners.
 */
class RoundedPanel extends JPanel {
    private final int radius;
    private final Color backgroundColor;

    /**
     * Constructs a RoundedPanel with the specified radius and background color.
     *
     * @param radius the radius of the rounded corners
     * @param backgroundColor the background color of the panel
     */
    public RoundedPanel(int radius, Color backgroundColor) {
        super();
        this.radius = radius;
        this.backgroundColor = backgroundColor;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Dimension arcs = new Dimension(radius, radius);
        int width = getWidth();
        int height = getHeight();
        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setColor(backgroundColor);
        graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);
    }
}
