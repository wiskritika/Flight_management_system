package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.data.BookingDataManager;
import bcu.cmp5332.bookingsystem.data.FlightBookingSystemData;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class MainWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    private JPanel mainPanel;
    private JPanel sidebarPanel;

    private JLabel linkViewFlights;
    private JLabel linkPassengerList;
    private JLabel linkAddBooking;
    private JLabel linkCancelBooking;
    private JLabel linkViewBookings;
    private JLabel linkViewCustomers;
    private JLabel linkAddCustomer;
    private JLabel linkDeleteCustomer;
    private JLabel linkExit;

    private FlightBookingSystem fbs;

    public MainWindow(FlightBookingSystem fbs) {
        this.fbs = fbs;
        initialize();
        setTitle("Flight Booking System");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public FlightBookingSystem getFlightBookingSystem() {
        return fbs;
    }

    private void initialize() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            // Handle exception
        }

        setTitle("Flight Booking Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 600);
        setLayout(new BorderLayout());

        // Sidebar Panel
        sidebarPanel = new JPanel();
        sidebarPanel.setLayout(new GridLayout(0, 1, 10, 10));
        sidebarPanel.setPreferredSize(new Dimension(200, getHeight()));
        sidebarPanel.setBackground(Color.DARK_GRAY);
        sidebarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Labels as links
        linkViewFlights = createSidebarLink("View Flights");
        linkPassengerList = createSidebarLink("Passenger List");
        linkAddBooking = createSidebarLink("Add Booking");
        linkCancelBooking = createSidebarLink("Cancel Booking");
        linkViewBookings = createSidebarLink("View Bookings");
        linkViewCustomers = createSidebarLink("View Customers");
        linkAddCustomer = createSidebarLink("Add Customer");
        linkDeleteCustomer = createSidebarLink("Delete Customer");
        linkExit = createSidebarLink("Exit");

        // Adding Links to Sidebar
        sidebarPanel.add(linkViewFlights);
//        sidebarPanel.add(linkAddFlight);
//        sidebarPanel.add(linkDeleteFlight);
        sidebarPanel.add(linkPassengerList);
        sidebarPanel.add(linkAddBooking);
        sidebarPanel.add(linkCancelBooking);
        sidebarPanel.add(linkViewBookings);
        sidebarPanel.add(linkViewCustomers);
        sidebarPanel.add(linkAddCustomer);
        sidebarPanel.add(linkDeleteCustomer);
        sidebarPanel.add(linkExit);  // Moved to the last position

        add(sidebarPanel, BorderLayout.WEST);

        // Load background image
        mainPanel = new BackgroundPanel("resources/images/background1.jpg");
        mainPanel.setLayout(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);

        JLabel welcomeLabel = new JLabel("<html><center>WELCOME TO THE FLIGHT MANAGEMENT SYSTEM<br></center></html>");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 36));
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));

        // Add the welcome label to the top of the main panel
        mainPanel.add(welcomeLabel, BorderLayout.NORTH);

        setVisible(true);
        setAutoRequestFocus(true);
        toFront();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private JLabel createSidebarLink(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setForeground(Color.WHITE);
        label.setHorizontalAlignment(SwingConstants.LEFT);
        label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleSidebarLinkClick(label);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                label.setForeground(Color.LIGHT_GRAY);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                label.setForeground(Color.WHITE);
            }
        });

        return label;
    }

    private void handleSidebarLinkClick(JLabel label) {
        if (label == linkExit) {
            try {
                FlightBookingSystemData.store(fbs);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, ex, "Error", JOptionPane.ERROR_MESSAGE);
            }
            System.exit(0);
        } else if (label == linkViewFlights) {
            mainPanel.removeAll();
            DisplayFlightsWindow flightsWindow = new DisplayFlightsWindow(fbs, this);
            mainPanel.add(flightsWindow, BorderLayout.CENTER);
            mainPanel.revalidate();
        } 
//        else if (label == linkAddFlight) {
//            new AddFlightWindow(this);
//        } 
//        else if (label == linkDeleteFlight) {
//            new DeleteFlightWindow(fbs);
//        } 
        else if (label == linkPassengerList) {
            displayPassengerList();
        } else if (label == linkAddBooking) {
            new AddBookingWindow(this);
        } else if (label == linkCancelBooking) {
            new CancelBookingWindow(this);
        }
        else if (label == linkViewBookings) {
            mainPanel.removeAll();
            DisplayBookingWindow bookingsWindow = new DisplayBookingWindow();
            mainPanel.add(bookingsWindow, BorderLayout.CENTER);
            mainPanel.revalidate();
        } else if (label == linkAddCustomer) {
            new AddCustomerWindow(this);
        } else if (label == linkViewCustomers) {
            showDisplayCustomersWindow();
        } else if (label == linkDeleteCustomer) {
            new DeleteCustomerWindow(fbs);
        }
    }

    private void displayPassengerList() {
        JPanel panel = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Enter Flight ID:");
        JTextField inputField = new JTextField();
        panel.add(label, BorderLayout.WEST);
        panel.add(inputField, BorderLayout.CENTER);

        // Customize input dialog buttons
        UIManager.put("OptionPane.okButtonText", "OK");
        UIManager.put("OptionPane.cancelButtonText", "Cancel");
        UIManager.put("OptionPane.okButtonBackground", new Color(0, 0, 128)); // Navy blue background for OK button
        UIManager.put("OptionPane.cancelButtonBackground", new Color(0, 0, 128)); // Navy blue background for Cancel button
        UIManager.put("Button.background", new Color(169, 169, 169)); // Gray background

        int result = JOptionPane.showConfirmDialog(this, panel, "Passenger List", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        String input = inputField.getText();
        if (result == JOptionPane.OK_OPTION && !input.isEmpty()) {
            try {
                int flightId = Integer.parseInt(input);
                Flight flight = fbs.getFlightByID(flightId);
                if (flight != null) {
                    List<Customer> passengers = flight.getPassengers();
                    new PassengerListWindow(passengers, flight.getFlightNumber());
                } else {
                    // Customize error message dialog
                    UIManager.put("OptionPane.messageForeground", Color.RED); // Red text for error message
                    JOptionPane.showMessageDialog(this, "Flight not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Customize error message dialog
                UIManager.put("OptionPane.messageForeground", Color.RED); // Red text for error message
                JOptionPane.showMessageDialog(this, "Please enter a valid flight ID.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (FlightBookingSystemException ex) {
                // Customize error message dialog
                UIManager.put("OptionPane.messageForeground", Color.RED); // Red text for error message
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void showDisplayCustomersWindow() {
        mainPanel.removeAll();
        DisplayCustomerWindow customersWindow = new DisplayCustomerWindow(fbs);
        mainPanel.add(customersWindow, BorderLayout.CENTER);
        mainPanel.revalidate();
    }

    public void showBookingDetails(Customer customer) {
        List<Booking> bookings = customer.getBookings();

        String[] columns = {"Booking ID", "Flight", "Booking Date", "Price", "Cancellation Fee", "Rebook Fee"};
        Object[][] data = new Object[bookings.size()][6];
        int i = 0;
        for (Booking booking : bookings) {
            data[i][0] = booking.getId();
            data[i][1] = booking.getFlight().getFlightNumber();
            data[i][2] = booking.getBookingDate();
            data[i][3] = booking.getPrice();
            data[i][4] = booking.getCancellationFee();
            data[i][5] = booking.getRebookFee();
            i++;
        }

        JTable table = new JTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(table);

        JFrame frame = new JFrame("Booking Details");
        frame.getContentPane().add(scrollPane);
        frame.setSize(600, 400);
        frame.setVisible(true);
    }

    public void displayFlights() {
        List<Flight> flightsList = fbs.getFlights();
        LocalDate today = LocalDate.now();

        String[] columns = new String[]{"Flight ID", "Flight No", "Origin", "Destination", "Departure Date", "Number of Seats", "Price", "Fully Booked", "Departed"};

        Object[][] data = new Object[flightsList.size()][9];
        for (int i = 0; i < flightsList.size(); i++) {
            Flight flight = flightsList.get(i);
            boolean fullyBooked = flight.isFullyBooked();
            boolean departed = !flight.hasNotDeparted(today); // Check if flight has departed

            String price;
            try {
                price = String.valueOf(flight.calculatePrice(today));
            } catch (FlightBookingSystemException ex) {
                // Handle the exception by setting a placeholder message for the price
                price = "Price calculation error";
            }

            data[i][0] = flight.getId();
            data[i][1] = flight.getFlightNumber();
            data[i][2] = flight.getOrigin();
            data[i][3] = flight.getDestination();
            data[i][4] = flight.getDepartureDate();
            data[i][5] = flight.getNumberOfSeats();
            data[i][6] = price;
            data[i][7] = fullyBooked ? "Yes" : "No";
            data[i][8] = departed ? "Yes" : "No";
        }

        JTable table = new JTable(data, columns);
        this.getContentPane().removeAll();
        this.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
        this.revalidate();
    }

    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel(String filePath) {
            try {
                backgroundImage = new ImageIcon(filePath).getImage();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        }
    }
}