package bcu.cmp5332.bookingsystem.gui;

import bcu.cmp5332.bookingsystem.commands.AddCustomer;
import bcu.cmp5332.bookingsystem.commands.Command;
import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * It represents a window for adding a new customer to the flight booking system.
 * 
 * @author Kritika, Kevin
 */
public class AddCustomerWindow extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private static AddCustomerWindow instance;

    private MainWindow mw;
    private JTextField nameText = new JTextField();
    private JTextField phoneText = new JTextField();
    private JTextField emailText = new JTextField();

    private JButton addBtn = new JButton("Add");
    private JButton cancelBtn = new JButton("Cancel");

    /**
     * Constructs an AddCustomerWindow object with the specified MainWindow.
     *
     * @param mw The MainWindow object.
     */
    public AddCustomerWindow(MainWindow mw) {
        this.mw = mw;
        initialize();
    }

    /**
     * Returns the instance of AddCustomerWindow.
     *
     * @param mw The MainWindow object.
     * @return The AddCustomerWindow instance.
     */
    public static AddCustomerWindow getInstance(MainWindow mw) {
        if (instance == null) {
            instance = new AddCustomerWindow(mw);
        }
        return instance;
    }

    /**
     * Initializes the AddCustomerWindow by setting up the UI components.
     */
    private void initialize() {
        setTitle("Add Customer");
        setSize(600, 600); // Adjusted size for better fit
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Dispose on close to manage resources properly

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(new Color(6, 47, 84));

        JLabel headingLabel = new JLabel("Add Customer", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headingLabel.setForeground(Color.WHITE);
        headingLabel.setOpaque(true);
        headingLabel.setBackground(new Color(6, 47, 84)); 
        headingLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        contentPanel.add(headingLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(6, 47, 84)); // Dark blue background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components

        // Labels with larger font size
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        nameLabel.setForeground(Color.WHITE); // White text
        formPanel.add(nameLabel, gbc);

        gbc.gridy++;
        nameText.setPreferredSize(new Dimension(250, 30)); // Adjusted width for text field
        nameText.setBackground(new Color(200, 200, 200)); // Light gray background
        nameText.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(nameText, gbc);

        gbc.gridy++;
        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 16));
        phoneLabel.setForeground(Color.WHITE); // White text
        formPanel.add(phoneLabel, gbc);

        gbc.gridy++;
        phoneText.setPreferredSize(new Dimension(250, 30)); // Adjusted width for text field
        phoneText.setBackground(new Color(200, 200, 200)); // Light gray background
        phoneText.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(phoneText, gbc);

        gbc.gridy++;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 16));
        emailLabel.setForeground(Color.WHITE); // White text
        formPanel.add(emailLabel, gbc);

        gbc.gridy++;
        emailText.setPreferredSize(new Dimension(250, 30)); // Adjusted width for text field
        emailText.setBackground(new Color(200, 200, 200)); // Light gray background
        emailText.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(emailText, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(6, 47, 84)); // Dark blue background
        addBtn.setFont(new Font("Arial", Font.BOLD, 14));
        addBtn.setForeground(Color.BLACK); // Black text for better visibility
        addBtn.setBackground(Color.WHITE); // White background for button
        cancelBtn.setFont(new Font("Arial", Font.BOLD, 14));
        cancelBtn.setForeground(Color.BLACK); // Black text for better visibility
        cancelBtn.setBackground(Color.WHITE); // White background for button
        buttonPanel.add(addBtn);
        buttonPanel.add(cancelBtn);

        addBtn.addActionListener(this);
        cancelBtn.addActionListener(this);

        contentPanel.add(formPanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        setContentPane(contentPanel);
        setLocationRelativeTo(mw);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == addBtn) {
            addCustomer();
        } else if (ae.getSource() == cancelBtn) {
            this.dispose();
        }
    }

    /**
     * Adds a new customer to the flight booking system based on the user input.
     */
    private void addCustomer() {
        try {
            String name = nameText.getText().trim();
            String phone = phoneText.getText().trim();
            String email = emailText.getText().trim();

            if (name.isEmpty() || phone.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Create and execute the AddCustomer Command
            Command addCustomer = new AddCustomer(name, phone, email);
            addCustomer.execute(mw.getFlightBookingSystem());

            // Display success message
            JOptionPane.showMessageDialog(this, "Customer added successfully");

            // Refresh the view with the DisplayCustomersWindow
            mw.showDisplayCustomersWindow();

            // Hide (close) the AddCustomerWindow
            this.dispose();
        } catch (FlightBookingSystemException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
