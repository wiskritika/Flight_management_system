package bcu.cmp5332.bookingsystem.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import bcu.cmp5332.bookingsystem.model.Customer;

/**
 * A JFrame for displaying the list of passengers for a flight.
 */
public class PassengerListWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new PassengerListWindow.
     *
     * @param passengers   The list of passengers.
     * @param flightNumber The flight number.
     */
    public PassengerListWindow(List<Customer> passengers, String flightNumber) {
        setTitle("Passenger List for Flight " + flightNumber);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 500); // Set size to 600x500 pixels
        getContentPane().setBackground(Color.WHITE); // Set background to white

        // Create heading label
        JLabel headingLabel = new JLabel("Passenger List", JLabel.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headingLabel.setOpaque(true);
        headingLabel.setBackground(new Color(60, 63, 65)); // Dark gray for heading background
        headingLabel.setForeground(Color.WHITE); // White text for contrast
        headingLabel.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 0, 10, 0));

        // Create panel for the table
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE); // Set background to white

        String[] columnNames = {"ID", "Name", "Phone", "Email"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        // Filter out cancelled bookings from the list of passengers
        List<Customer> activePassengers = passengers.stream()
                .filter(customer -> !customer.isCancelled())
                .collect(Collectors.toList());

        for (Customer passenger : activePassengers) {
            Object[] rowData = {passenger.getId(), passenger.getName(), passenger.getPhone(), passenger.getEmail()};
            model.addRow(rowData);
        }

        JTable table = new JTable(model);
        table.setFont(new Font("Arial", Font.BOLD, 14)); // Set font to bold
        table.setRowHeight(30); // Adjust row height
        table.setBackground(Color.WHITE); // Set background to white
        table.setForeground(Color.BLACK); // Set text color to black

        // Customize table header
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Arial", Font.BOLD, 14)); // Set font to bold
        header.setBackground(Color.WHITE); // Set header background to white
        header.setForeground(Color.BLACK); // Set header text color to black
        header.setReorderingAllowed(false); // Disable column reordering

        // Center-align cell content
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        centerRenderer.setBackground(Color.WHITE); // Ensure cell background is white
        centerRenderer.setForeground(Color.BLACK); // Ensure cell text color is black
        centerRenderer.setFont(new Font("Arial", Font.BOLD, 14)); // Ensure cell text is bold
        table.setDefaultRenderer(Object.class, centerRenderer);

        // Ensure selection color is consistent
        table.setSelectionBackground(Color.LIGHT_GRAY); // Light gray for selected rows background
        table.setSelectionForeground(Color.BLACK); // Black text for selected rows

        tablePanel.add(header, BorderLayout.NORTH);
        tablePanel.add(table, BorderLayout.CENTER);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(headingLabel, BorderLayout.NORTH);
        getContentPane().add(tablePanel, BorderLayout.CENTER);

        setLocationRelativeTo(null); // Center the window on the screen
        setVisible(true);
    }
}
